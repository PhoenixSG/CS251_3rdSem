Hello and welcome to our app.
You can find an apk in this folder -> app\build\outputs\apk\debug\app-debug.apk
!!! Please change the local.properties before running !!!
The device configuration used by us is Pixel 5 API 30

We will go over some of the features we have added in our app-

All specifications required, including navigation view, recycler view, fragments etc.
Full support for dark mode and landscape mode.
Store title, description, date, time in task object, alongwith the type of task.
Option to Add, Update and Delete tasks.

Calender fully implemented in house and selected date highlighted.
All the tasks are arranged in order of scheduled time. Most Urgent one at the top.
Interactive date and time pickers.
Option to view all the tasks at once.

The references folder is also included with the project.

Have fun!
